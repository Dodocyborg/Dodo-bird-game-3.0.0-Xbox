#include "EncryptionManager.h"

std::string EncryptionManager::encrypt(const std::string& data) {
    // Stub: return data unchanged (for demo)
    return data;
}

std::string EncryptionManager::decrypt(const std::string& encryptedData) {
    // Stub: return data unchanged (for demo)
    return encryptedData;
}